import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        People[] PeopleDATA = new People[0];
        PeopleDATA = Functions.Read(PeopleDATA);
        String action = "";
        while (!action.equals("5")){
            action = Functions.Input("\nWelcome to the system!\n\nAdd data -- 1\nShow data -- 2\nChange data -- 3\nDelete data -- 4\nQuit system -- 5\n\nInput: ");
            switch (action) {
                case "1":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input("Add data\nPress 'q' to exit input\nInput telephone number: ");
                    try {
                        PeopleDATA = Functions.AddData(PeopleDATA, num);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "2":
                System.out.println("Show data");
                System.out.println("   Telephone number  Name   Living place   Added time");
                for(int i = 0; i < PeopleDATA.length; i++){
                    System.out.println((i + 1) + ". " + String.format("%-18s", PeopleDATA[i].getTelNum()) + String.format("%-4.4s", PeopleDATA[i].getName()) + ((PeopleDATA[i].getName().length() > 4) ? "..." : "   ") + String.format("%-12.12s", PeopleDATA[i].getLivingPlace()) + ((PeopleDATA[i].getLivingPlace().length() > 12) ? "..." : "   ") + ((LocalDateTime.now().getDayOfYear() == PeopleDATA[i].addedTime.getDayOfYear()) ? "Today" : ((LocalDateTime.now().getDayOfYear() - PeopleDATA[i].addedTime.getDayOfYear() == 1) ? "Yesterday" :((LocalDateTime.now().getDayOfYear() - PeopleDATA[i].addedTime.getDayOfYear() < 7) ? (LocalDateTime.now().getDayOfYear() - PeopleDATA[i].addedTime.getDayOfYear() + " days ago") : PeopleDATA[i].addedTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))))));
                }
                
                if (PeopleDATA.length == 0){
                    System.out.println("Empty here...");
                }
                
                for (int i = 0; i < 1;){
                    action = Functions.Input("\nPress a number to view details about a people\nPress 'q' to exit\n\nInput: ");
                    try {
                        int a = Integer.parseInt(action);
                        try {
                            System.out.println("\nDetailed information:\nTelephone number: " + PeopleDATA[a - 1].getTelNum() + "\nName: " + PeopleDATA[a - 1].getName() + "\nLiving place: " + PeopleDATA[a - 1].getLivingPlace() + "\nAdded time: " + PeopleDATA[a - 1].addedTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss")));
                        } catch (Exception e) {
                            System.out.println(Functions.ColorfulString("No such an index!", 31));
                        }
                    } catch (Exception e) {
                        if (action.equals("q")){
                            i++;
                        }
                        else{
                            System.out.println(Functions.ColorfulString("Unknown input!", 31));
                        }
                    }
                }
                
                break;
                case "3":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input("Change data\nPress 'q' to exit input\nInput telephone number: ");
                    try {
                        PeopleDATA = Functions.ChangeData(PeopleDATA, num);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "4":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input("Delete data\nPress 'q' to exit input\nInput telephone number: ");
                    try {
                        PeopleDATA = Functions.DeleteData(PeopleDATA, num);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "5":
                Functions.SaveData(PeopleDATA);
                System.out.println("Quitting...");
                break;
        
                default:
                    break;
            }
        }

    }
}
