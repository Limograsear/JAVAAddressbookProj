import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class Functions {
    static String ColorfulString(String s, int color){
        return "\033[10;" + Integer.toString(color) + ";48m" + s + "\033[0m";
    }
    static People[] Read(People[] p){
        People[] p1 = p;
        try{
            BufferedReader reader = new BufferedReader(new FileReader("./DATA/DataFile.txt"));
            String line;
            int m = 0;
            while ((line = reader.readLine()) != null){
                switch (m % 4) {
                    case 0:
                    p1 = new People[p.length + 1];
                    for (int i = 0; i < p.length; i++){
                        p1[i] = p[i];
                    }
                    p1[p.length] = new People(line, null, null);
                    p = p1;
                    break;
                    case 1:
                    p1[p.length - 1].setName(line);
                    break;
                    case 2:
                    p1[p.length - 1].setLivingPlace(line);
                    break;
                    case 3:
                    int[] date = new int[]{-1, -1, -1, -1, -1, -1};
                    int temp = 0;
                    for (int i = 0; i < line.length(); i++){
                        if (line.charAt(i) == ' '){
                            for (int n = 0; n < 6; n++){
                                if (date[n] == -1){
                                    date[n] = Integer.parseInt(line.substring(temp, i));
                                    temp = i + 1;
                                    break;
                                }
                            }
                        }
                    }
                    p1[p.length - 1].addedTime = LocalDateTime.of(date[0], date[1], date[2], date[3], date[4], date[5]);
                    break;
                    default:
                    break;
                }
                m++;
            }
            reader.close();
        }
        catch(IOException e){
            System.out.println(ColorfulString("Data reading failed! Maybe no Database exists\nBur don't worry, we will create one when you exit :-)", 31));
        }
        return p1;
    }
    static String Input(String Notice){
        System.out.print(Notice);
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        return s;
    }
    static People[] AddData(People[] p, String num) throws Exception {
        People[] p1 = p;
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                boolean isExists = false;
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        isExists = true;
                    }
                }
                if (isExists){
                    throw new Exception(String.format(ColorfulString("The number %s has already exists!", 31),num));
                }
                else{
                    p1 = new People[p.length+1];
                    for (int n = 0; n < p.length; n++){
                        p1[n] = p[n];
                    }
                    String name = Input("Input name: ");
                    String livingPlace = Input("Input living place: ");
                    p1[p.length] = new People(num,name,livingPlace);
                    System.out.println(ColorfulString("Add succeeded!", 32));
                }
            }
            else{
                throw new Exception(String.format(ColorfulString("%s is not a phone number!", 31),num));
            }
        }
        return p1;
    }
    static People[] ChangeData(People[] p, String num) throws Exception {
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        String name = Input("Input new name: ");
                        String livingPlace = Input("Input new living place: ");
                        p[n] = new People(num,name,livingPlace);
                        System.out.println(String.format(ColorfulString("Change telephone number %s succeeded!", 32),num));
                        break;
                    }
                    else{
                        if (n >= p.length - 1){
                            throw new Exception(String.format(ColorfulString("The telephone number %s not found!", 31), num));
                        }
                    }
                }
            }
            else{
                throw new Exception(String.format(ColorfulString("%s is not a phone number!", 31),num));
            }
        }
        return p;
    }
    static People[] DeleteData(People[] p, String num) throws Exception {
        People[] p1 = p;
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        p1 = new People[p.length - 1];
                        int x = 0;
                        for(int y = 0; y < p.length; y++){
                            if (y != n){
                                p1[x] = p[y];
                                x++;
                            }
                        }
                        System.out.println(String.format(ColorfulString("Delete telephone number %s succeeded!", 32),num));
                        break;
                    }
                    else{
                        if (n >= p.length - 1){
                            throw new Exception(String.format(ColorfulString("The telephone number %s not found!", 31), num));
                        }
                    }
                }
            }
            else{
                throw new Exception(String.format(ColorfulString("%s is not a phone number!", 31),num));
            }
        }
        return p1;
    }
    static void SaveData(People[] p){
        File DataFile = new File("./DATA/DataFile.txt");
        try {
            DataFile.createNewFile();
            try {
                
                BufferedWriter writer = new BufferedWriter(new FileWriter(DataFile));
                for (int n = 0; n < p.length; n++){
                        writer.write(p[n].getTelNum() + "\n" + p[n].getName() + "\n" + p[n].getLivingPlace() + "\n" + p[n].addedTime.getYear() + " " + p[n].addedTime.getMonthValue() + " " + p[n].addedTime.getDayOfMonth() + " " + p[n].addedTime.getHour() + " " + p[n].addedTime.getMinute() + " " + p[n].addedTime.getSecond() + " \n");
                }
                writer.close();
            } catch (IOException e) {
                System.out.println(ColorfulString("Save failed!", 31));
            }
            System.out.println(ColorfulString("Save succeeded!", 32));
        } catch (IOException e) {
            System.out.println(ColorfulString("Save failed!", 31));
        }
        
    }
}
