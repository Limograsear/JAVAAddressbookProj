import java.time.LocalDateTime;

class People{
    private String telNum, name, livingPlace;
    LocalDateTime addedTime;
    public People(String TELNUM, String NAME, String LIVINGPLACE){
        this.telNum = TELNUM;
        this.name = NAME;
        this.livingPlace = LIVINGPLACE;
        this.addedTime = LocalDateTime.now();
    }
    String getTelNum(){
        return this.telNum;
    }
    String getName(){
        return this.name;
    }
    String getLivingPlace(){
        return this.livingPlace;
    }
    void setTelNum(String TELNUM){
        this.telNum = TELNUM;
    }
    void setName(String NAME){
        this.name = NAME;
    }
    void setLivingPlace(String LIVINGPLACE){
        this.livingPlace = LIVINGPLACE;
    }
}