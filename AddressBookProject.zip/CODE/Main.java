import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.LocalDateTime;

public class Main {
    public static boolean[] Setting = new boolean[]{false,true,false};
    public static void main(String[] args) {
        People[] PeopleDATA = new People[0];
        PeopleDATA = Functions.Read(PeopleDATA, Setting[1]);
        String action = "";
        while (!action.equals("6")){
            action = Functions.Input(Setting[1] ? "\nWelcome to the system!\n\nAdd data -- 1\nShow data -- 2\nChange data -- 3\nDelete data -- 4\nSetting -- 5\nQuit system -- 6\n\nInput: " : "\n欢迎来到系统\n\n添加数据 -- 1\n展示数据 -- 2\n更改数据 -- 3\n删除数据 -- 4\n设置 -- 5\n退出系统 -- 6\n\n请输入: ");
            switch (action) {
                case "1":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input(Setting[1] ? "Add data\nPress 'q' to exit input\nInput telephone number: " : "添加数据\n按 'q' 退出输入\n输入电话号码: ");
                    try {
                        PeopleDATA = Functions.AddData(PeopleDATA, num, Setting[1]);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "2":
                System.out.println(Setting[1] ? Functions.ToCaps("Show data", Setting[2]) : "展示数据");
                System.out.print((Setting[0]) ? "+---------------------------------------------------------+\n" : "");
                System.out.println(((Setting[0]) ? "|" : "" )+ ((Setting[1]) ? Functions.ToCaps("   Telephone number  Name   Living place   Added time    ", Setting[2]) : "   电话号码          姓名   居住地         添加时间      ") + ((Setting[0]) ? "|" : ""));
                System.out.print((Setting[0]) ? "+---------------------------------------------------------+\n" : "");
                if (PeopleDATA.length == 0){
                    System.out.println(((Setting[0]) ? "|" : "" ) + (Setting[1] ? String.format("%-57.57s", Functions.ToCaps("Empty here...", Setting[2])) : String.format("%-50.50s", "这里什么也没有...")) + ((Setting[0]) ? "|" : ""));
                }
                for(int i = 0; i < PeopleDATA.length; i++){
                    long DateBetween = ChronoUnit.SECONDS.between(PeopleDATA[i].addedTime, LocalDateTime.now());
                    System.out.print((Setting[0]) ? "|" : "");
                    System.out.print((i + 1) + ". " + String.format("%-18s", PeopleDATA[i].getTelNum()) + String.format("%-4.4s", PeopleDATA[i].getName()) + ((PeopleDATA[i].getName().length() > 4) ? "..." : "   ") + ((Setting[1]) ? String.format("%-12.12s", PeopleDATA[i].getLivingPlace()) + ((PeopleDATA[i].getLivingPlace().length() > 12) ? "..." : "   ") : String.format("%-6.6s", PeopleDATA[i].getLivingPlace()) + ((PeopleDATA[i].getLivingPlace().length() > 6) ? "..." : "   ")+"      ") + String.format("%-14.14s", (String)(((DateBetween <= 60) ? Functions.ToCaps("Just now", Setting[2]) : (DateBetween <= 3600) ? (DateBetween/60)+Functions.ToCaps(" minute", Setting[2])+ ((DateBetween / 60 < 2) ? "" : Functions.ToCaps("s", Setting[2])) + Functions.ToCaps(" ago", Setting[2]) : ((DateBetween <= 3600*24) ? (DateBetween/3600)+Functions.ToCaps(" hour", Setting[2]) + ((DateBetween / 3600 < 2) ? "" : Functions.ToCaps("s", Setting[2])) + Functions.ToCaps(" ago", Setting[2]) : PeopleDATA[i].addedTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")))))));
                    System.out.println((Setting[0]) ? "|" : "");
                }
                System.out.print((Setting[0]) ? "+---------------------------------------------------------+\n" : "");
                
                
                for (int i = 0; i < 1;){
                    action = Functions.Input(Setting[1] ? Functions.ToCaps("\nPress a number to view details about a people\nPress 'q' to exit\n\nInput: ", Setting[2]) : "\n按下一个数字查看一名成员的详细信息\n按 'q' 退出\n\n请输入: ");
                    try {
                        int a = Integer.parseInt(action);
                        try {
                            System.out.println((Setting[1] ? Functions.ToCaps("\nDetailed information:\nTelephone number: ", Setting[2]) : "\n详细信息:\n电话号码: ") + PeopleDATA[a - 1].getTelNum() + (Setting[1] ? Functions.ToCaps("\nName: ", Setting[2]) : "\n姓名: ") + PeopleDATA[a - 1].getName() + (Setting[1] ? Functions.ToCaps("\nLiving place: ", Setting[2]) : "\n居住地: ") + PeopleDATA[a - 1].getLivingPlace() + (Setting[1] ? Functions.ToCaps("\nAdded time: ", Setting[2]) : "\n添加时间: ") + PeopleDATA[a - 1].addedTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss")));
                        } catch (Exception e) {
                            System.out.println(Functions.ColorfulString(Setting[1] ? Functions.ToCaps("No such an index!", Setting[2]) : "未发现数字所在成员!", 31));
                        }
                    } catch (Exception e) {
                        if (action.equals("q")){
                            i++;
                        }
                        else{
                            System.out.println(Functions.ColorfulString(Setting[1] ? Functions.ToCaps("Unknown input!", Setting[2]) : "未知输入!", 31));
                        }
                    }
                }
                
                break;
                case "3":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input(Setting[1] ? "Change data\nPress 'q' to exit input\nInput telephone number: " : "更改数据\n按 'q' 退出输入\n输入电话号码: ");
                    try {
                        PeopleDATA = Functions.ChangeData(PeopleDATA, num, Setting[1]);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "4":
                for(int i = 0; i < 1; i++){
                    String num = Functions.Input(Setting[1] ? "Delete data\nPress 'q' to exit input\nInput telephone number: " : "删除数据\n按 'q' 退出输入\n输入电话号码: ");
                    try {
                        PeopleDATA = Functions.DeleteData(PeopleDATA, num, Setting[1]);
                    } catch (Exception e) {
                        i--;
                        System.out.println(e.getMessage());
                    }
                }
                break;
                case "5":
                System.out.println(Setting[1] ? Functions.ToCaps("Setting", Setting[2]) : "设置");
                for (int i = 0; i < 1;){
                    action = Functions.Input(String.format((Setting[1] ? Functions.ToCaps("\nShow border when showing data: %s -- 1\nChange language: %s -- 2\nWord style: %s -- 3\nPress a number to choose the setting style\nPress 'q' to exit\n\nInput: ", Setting[2]) : "\n显示数据时,显示表格边框: %s -- 1\n更改语言: %s -- 2\n按下一个数字选择设置内容\n按 'q' 退出\n\n请输入: "),(Setting[0] ? (Setting[1] ? Functions.ToCaps("On", Setting[2]) : "开") : (Setting[1] ? Functions.ToCaps("Off", Setting[2]) : "关")),(Setting[1] ? Functions.ToCaps("English", Setting[2]) : "简体中文"),(Setting[2] ? "EXAMPLE" : "Example")));
                    try {
                        int a = Integer.parseInt(action);
                        try {
                            if (!(!Setting[1] && a == 3)){
                                Setting[a - 1] = !Setting[a - 1];
                            }
                            else{
                                throw new Exception();
                            }

                        } catch (Exception e) {
                            System.out.println(Functions.ColorfulString(Setting[1] ? Functions.ToCaps("No such an index!", Setting[2]) : "无该设置选项, 或该设置选项在该语言环境下不可用!", 31));
                        }
                    } catch (Exception e) {
                        if (action.equals("q")){
                            i++;
                        }
                        else{
                            System.out.println(Functions.ColorfulString(Setting[1] ? Functions.ToCaps("Unknown input!", Setting[2]) : "未知输入!", 31));
                        }
                    }
                }
                break;
                case "6":
                Functions.SaveData(PeopleDATA, Setting[1]);
                System.out.println(Setting[1] ? Functions.ToCaps("Quitting...", Setting[2]) : "正在退出...");
                break;
        
                default:
                    break;
            }
        }
    }
}
