import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class Functions {
    static String ColorfulString(String s, int color){
        return "\033[10;" + Integer.toString(color) + ";48m" + s + "\033[0m";
    }
    static String ToCaps(String s, boolean isCap){
        if (!isCap){
            return s;
        }
        else{
            return s.toUpperCase();
        }
    }
    static People[] Read(People[] p, boolean lang){
        People[] p1 = p;
        try{
            BufferedReader reader = new BufferedReader(new FileReader("./DATA/DataFile.txt"));
            String line;
            int m = 0;
            while ((line = reader.readLine()) != null){
                switch (m % 4) {
                    case 0:
                    p1 = new People[p.length + 1];
                    for (int i = 0; i < p.length; i++){
                        p1[i] = p[i];
                    }
                    p1[p.length] = new People(line, null, null);
                    p = p1;
                    break;
                    case 1:
                    p1[p.length - 1].setName(line);
                    break;
                    case 2:
                    p1[p.length - 1].setLivingPlace(line);
                    break;
                    case 3:
                    int[] date = new int[]{-1, -1, -1, -1, -1, -1};
                    int temp = 0;
                    for (int i = 0; i < line.length(); i++){
                        if (line.charAt(i) == ' '){
                            for (int n = 0; n < 6; n++){
                                if (date[n] == -1){
                                    date[n] = Integer.parseInt(line.substring(temp, i));
                                    temp = i + 1;
                                    break;
                                }
                            }
                        }
                    }
                    p1[p.length - 1].addedTime = LocalDateTime.of(date[0], date[1], date[2], date[3], date[4], date[5]);
                    break;
                    default:
                    break;
                }
                m++;
            }
            reader.close();
        }
        catch(IOException e){
            System.out.println(ColorfulString(lang ? ToCaps("Data reading failed! Maybe no Database exists\nBut don't worry, we will create one when you exit :-)",Main.Setting[2]) : "数据读取失败! 可能是因为数据库不存在\n不过无需担心, 我们将在您退出时创建一个 :-)", 31));
        }
        return p1;
    }
    static String Input(String Notice){
        System.out.print(ToCaps(Notice,Main.Setting[2]));
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        return s;
    }
    static People[] AddData(People[] p, String num, boolean lang) throws Exception {
        People[] p1 = p;
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                boolean isExists = false;
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        isExists = true;
                    }
                }
                if (isExists){
                    throw new Exception(String.format(ColorfulString(lang ? ToCaps("The number %s has already exists!",Main.Setting[2]) : "电话号码 %s 已存在!", 31),num));
                }
                else{
                    p1 = new People[p.length+1];
                    for (int n = 0; n < p.length; n++){
                        p1[n] = p[n];
                    }
                    String name = Input(lang ? "Input name: " : "输入姓名: ");
                    String livingPlace = Input(lang ? "Input living place: " : "输入居住地: ");
                    p1[p.length] = new People(num,name,livingPlace);
                    System.out.println(ColorfulString(lang ? ToCaps("Add succeeded!",Main.Setting[2]) : "添加成功!", 32));
                }
            }
            else{
                throw new Exception(String.format(ColorfulString(lang ? ToCaps("%s is not a phone number!",Main.Setting[2]) : "%s 不是一个电话号码!", 31),num));
            }
        }
        return p1;
    }
    static People[] ChangeData(People[] p, String num, boolean lang) throws Exception {
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        String name = Input(lang ? "Input new name: " : "输入新姓名: ");
                        String livingPlace = Input(lang ? "Input new living place: " : "输入新居住地: ");
                        p[n] = new People(num,name,livingPlace);
                        System.out.println(String.format(ColorfulString(lang ? ToCaps("Change telephone number %s succeeded!",Main.Setting[2]) : "改变电话号码 %s 的新内容成功!", 32),num));
                        break;
                    }
                    else{
                        if (n >= p.length - 1){
                            throw new Exception(String.format(ColorfulString(lang ? ToCaps("The telephone number %s not found!",Main.Setting[2]) : "电话号码 %s 未找到!", 31), num));
                        }
                    }
                }
            }
            else{
                throw new Exception(String.format(ColorfulString(lang ? ToCaps("%s is not a phone number!",Main.Setting[2]) : "%s 不是一个电话号码!", 31),num));
            }
        }
        return p;
    }
    static People[] DeleteData(People[] p, String num, boolean lang) throws Exception {
        People[] p1 = p;
        if(!num.equals("q")){
            if (num.matches("^[0-9]*$") && num.length() == 11){
                for (int n = 0; n < p.length; n++){
                    if (p[n].getTelNum().equals(num)){
                        p1 = new People[p.length - 1];
                        int x = 0;
                        for(int y = 0; y < p.length; y++){
                            if (y != n){
                                p1[x] = p[y];
                                x++;
                            }
                        }
                        System.out.println(String.format(ColorfulString(lang ? ToCaps("Delete telephone number %s succeeded!",Main.Setting[2]) : "删除电话号码 %s 成功!", 32),num));
                        break;
                    }
                    else{
                        if (n >= p.length - 1){
                            throw new Exception(String.format(ColorfulString(lang ? ToCaps("The telephone number %s not found!",Main.Setting[2]) : "电话号码 %s 未找到!", 31), num));
                        }
                    }
                }
            }
            else{
                throw new Exception(String.format(ColorfulString(lang ? ToCaps("%s is not a phone number!",Main.Setting[2]) : "%s 不是一个电话号码!", 31),num));
            }
        }
        return p1;
    }
    static void SaveData(People[] p, boolean lang){
        File DataFile = new File("./DATA/DataFile.txt");
        try {
            DataFile.createNewFile();
            try {
                
                BufferedWriter writer = new BufferedWriter(new FileWriter(DataFile));
                for (int n = 0; n < p.length; n++){
                        writer.write(p[n].getTelNum() + "\n" + p[n].getName() + "\n" + p[n].getLivingPlace() + "\n" + p[n].addedTime.getYear() + " " + p[n].addedTime.getMonthValue() + " " + p[n].addedTime.getDayOfMonth() + " " + p[n].addedTime.getHour() + " " + p[n].addedTime.getMinute() + " " + p[n].addedTime.getSecond() + " \n");
                }
                writer.close();
            } catch (IOException e) {
                System.out.println(ColorfulString(lang ? ToCaps("Save failed!",Main.Setting[2]) : "保存失败!", 31));
            }
            System.out.println(ColorfulString(lang ? ToCaps("Save succeeded!",Main.Setting[2]) : "保存成功!", 32));
        } catch (IOException e) {
            System.out.println(ColorfulString(lang ? ToCaps("Save failed!",Main.Setting[2]) : "保存失败!", 31));
        }
        
    }
}
